(() => {
    "use strict";
    let addWindowScrollEvent = false;
    setTimeout((() => {
        if (addWindowScrollEvent) {
            let windowScroll = new Event("windowScroll");
            window.addEventListener("scroll", (function(e) {
                document.dispatchEvent(windowScroll);
            }));
        }
    }), 0);
    window.addEventListener("DOMContentLoaded", (() => {
        document.addEventListener("click", documentActions);
        function documentActions(e) {
            const targetElement = e.target;
            if (targetElement.closest("[data-parent]")) {
                const subMenuId = targetElement.closest("[data-parent]").dataset.parent;
                const subMenu = document.querySelector(`[data-submenu="${subMenuId}"]`);
                if (subMenu) {
                    document.documentElement.classList.add("sub-menu-open");
                    document.querySelectorAll(".menu-item-active").forEach((el => {
                        el.classList.remove("menu-item-active");
                    }));
                    document.querySelectorAll("[data-submenu]._sub-menu-open").forEach((el => {
                        el.classList.remove("_sub-menu-open");
                    }));
                    subMenu.classList.add("_sub-menu-open");
                    targetElement.closest(".menu__item").classList.add("menu-item-active");
                }
                if (targetElement.closest(".submenu__back")) {
                    document.documentElement.classList.remove("sub-menu-open");
                    document.querySelectorAll(".menu-item-active").forEach((el => {
                        el.classList.remove("menu-item-active");
                    }));
                    document.querySelectorAll("[data-submenu]._sub-menu-open").forEach((el => {
                        el.classList.remove("_sub-menu-open");
                    }));
                }
            }
            if (targetElement.closest(".header__button") && window.innerWidth <= 768) document.documentElement.classList.toggle("menu-open");
            if (targetElement.closest(".submenu__back")) {
                document.documentElement.classList.remove("sub-menu-open");
                document.querySelectorAll(".menu-item-active").forEach((el => {
                    el.classList.remove("menu-item-active");
                }));
                document.querySelectorAll("[data-submenu]._sub-menu-open").forEach((el => {
                    el.classList.remove("_sub-menu-open");
                }));
            }
        }
    }));
})();